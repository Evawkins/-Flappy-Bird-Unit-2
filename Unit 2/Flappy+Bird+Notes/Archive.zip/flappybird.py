# Importing Pygame and Initialization
import pygame
pygame.init()

# Creating a Game Window
window_size = (800, 600)
screen = pygame.display.set_mode(window_size)

# Set the title of the window
pygame.display.set_caption('Eva\'s Game')

# Load an image
bird_image = pygame.image.load('/Users/evawilkins/Desktop/CS101/Units/Unit 2/Flappy+Bird+Notes/Flappy Bird Basics/bird1.png')  # Make sure to have an image named 'bird1.png' in the same folder

# Scale the image
bird_image = pygame.transform.scale(bird_image, (65, 50))

bird_x = 50
bird_y = 50

# A Simple Game Loop
running = True

while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_SPACE:
                print("Spacebar pressed")

    screen.fill((178, 217, 255))  # Fill the screen with white color

    pygame.draw.rect(screen, (255, 0, 0), (50, 50, 50, 50)) # window, color, position to draw the rectangle
    screen.blit(bird_image, (bird_x, bird_y))

    pygame.display.flip()

    pygame.time.delay(30)



pygame.quit()